package com.example.newroomproject;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.newroomproject.adapters.NewsAdapter;
import com.example.newroomproject.room.News;
import com.example.newroomproject.room.NewsDatabase;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  implements NewsAdapter.OnNewsClickListener {
    private FrameLayout fragmentContainer;
    private RecyclerView recyclerView;
    private NewsAdapter newsAdapter;
    private NewsDatabase database;
    private List<News> newsList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = NewsDatabase.getDatabase(this);

        // 初始化
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        newsList = new ArrayList<>();
        newsAdapter = new NewsAdapter(newsList, this,database,this,this);
        recyclerView.setAdapter(newsAdapter);

        // 加载数据
        loadNews();

        // 获取添加按钮
        FloatingActionButton fabAddNews = findViewById(R.id.fab_add_news);
        fabAddNews.setOnClickListener(v -> showAddNewsDialog());

        fragmentContainer = findViewById(R.id.fragment_container);

        // 默认显示 RecyclerView
        fragmentContainer.setVisibility(View.GONE);

    }


    private void showNewsDetailFragment(News news) {
        recyclerView.setVisibility(View.GONE);
        fragmentContainer.setVisibility(View.VISIBLE);

        // 创建 Fragment 并传递数据
        NewsDetailFragment fragment = new NewsDetailFragment();
        Bundle bundle = new Bundle();
        bundle.putString("title", news.getTitle());
        bundle.putString("content", news.getContent());
        bundle.putString("reporter", news.getReporterName());
        fragment.setArguments(bundle);

//      获取Fragment管理器
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null) // 添加到返回堆栈
                .commit();
    }


    private void loadNews() {
        new Thread(() -> {
            newsList.clear();
            newsList.addAll(database.newsDao().getAllNews());  // 获取所有新闻数据
            runOnUiThread(() -> newsAdapter.notifyDataSetChanged());
        }).start();
    }

//    添加新闻 弹出框
    private void showAddNewsDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_news, null);
        EditText editTitle = dialogView.findViewById(R.id.edit_title);
        EditText editContent = dialogView.findViewById(R.id.edit_content);
        EditText editReporter = dialogView.findViewById(R.id.edit_reporter);

        new AlertDialog.Builder(this)
                .setTitle("添加新闻")
                .setView(dialogView)
                .setPositiveButton("添加", (dialog, which) -> {
                    String title = editTitle.getText().toString();
                    String content = editContent.getText().toString();
                    String reporter = editReporter.getText().toString();
                    if (!title.isEmpty() && !content.isEmpty() && !reporter.isEmpty()) {
                        addNews(new News(title, content, reporter));
                    } else {
                        Toast.makeText(this, "请填写全部内容！", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

//    添加新闻数据
    private void addNews(News news) {
        new Thread(() -> {
            database.newsDao().insertNews(news);
            loadNews();
        }).start();
    }

    @Override
    public void onNewsClick(News news) {
        showNewsDetailFragment(news); // 点击新闻时显示详情页
    }


}
