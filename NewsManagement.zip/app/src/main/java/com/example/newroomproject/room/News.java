package com.example.newroomproject.room;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "news_table")
public class News {
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String title;
    private String content;
    private String reporterName;

    // Constructor
    public News(String title, String content, String reporterName) {
        this.title = title;
        this.content = content;
        this.reporterName = reporterName;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getReporterName() {
        return reporterName;  // Return the reporter's name
    }

    public void setReporterName(String reporterName) {
        this.reporterName = reporterName;
    }
}
