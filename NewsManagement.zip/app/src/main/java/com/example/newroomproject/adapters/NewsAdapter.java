package com.example.newroomproject.adapters;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.example.newroomproject.MainActivity;
import com.example.newroomproject.NewsDetailFragment;
import com.example.newroomproject.R;
import com.example.newroomproject.room.News;
import com.example.newroomproject.room.NewsDatabase;

import java.util.List;
public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder> {

    private List<News> newsList;
    private Context context;
    private NewsDatabase database;
    private Activity activity;
    private OnNewsClickListener listener;

    public NewsAdapter(List<News> newsList, Context context, NewsDatabase database, Activity activity,OnNewsClickListener listener) {
        this.newsList = newsList;
        this.context = context;
        this.database = database;
        this.activity = activity;
        this.listener = listener;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.news_item, parent, false);
        return new NewsViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        News news = newsList.get(position);
        holder.titleTextView.setText(news.getTitle());
        holder.contentTextView.setText(news.getContent());
        holder.reporterTextView.setText(news.getReporterName());

        // 设置点击事件 - 编辑按钮
        holder.editButton.setOnClickListener(v -> editNews(news));

        // 设置点击事件 - 删除按钮
        holder.deleteButton.setOnClickListener(v -> deleteNews(news));


        // 点击标题或者内容跳转到新闻详情
        holder.titleTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    listener.onNewsClick(news);
                }
            }
        });
        holder.contentTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    listener.onNewsClick(news);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return newsList.size();
    }


    // 编辑新闻的函数
    private void editNews(News news) {
        // 创建一个对话框用于编辑新闻
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("编辑新闻");

        // 创建一个布局并绑定到对话框
        View view = LayoutInflater.from(context).inflate(R.layout.dialog_add_news, null);
        builder.setView(view);

        // 获取视图中的控件
        EditText titleEditText = view.findViewById(R.id.edit_title);
        EditText contentEditText = view.findViewById(R.id.edit_content);
        EditText reporterEditText = view.findViewById(R.id.edit_reporter);

        // 预填充已有的数据
        titleEditText.setText(news.getTitle());
        contentEditText.setText(news.getContent());
        reporterEditText.setText(news.getReporterName());

        builder.setPositiveButton("保存", (dialog, which) -> {
            // 获取用户输入的内容
            String title = titleEditText.getText().toString();
            String content = contentEditText.getText().toString();
            String reporterName = reporterEditText.getText().toString();

            // 更新新闻对象
            news.setTitle(title);
            news.setContent(content);
            news.setReporterName(reporterName);

            // 在后台线程中执行更新操作
            new Thread(() -> {
                database.newsDao().updateNews(news);  // 这里使用 insertNews 方法进行更新
                activity.runOnUiThread(() -> {
                    // 刷新列表
                    notifyDataSetChanged();
                });
            }).start();
        });

        builder.setNegativeButton("取消", null);
        builder.show();
    }

    // 删除新闻
    private void deleteNews(News news) {
        new Thread(() -> {
            database.newsDao().deleteNews(news);
            activity.runOnUiThread(() -> {
                // 刷新列表
                newsList.remove(news);
                notifyDataSetChanged();
            });
        }).start();
    }

    public static class NewsViewHolder extends RecyclerView.ViewHolder {

        TextView titleTextView;
        TextView contentTextView;
        TextView reporterTextView;
        Button editButton;
        Button deleteButton;

        public NewsViewHolder(View itemView) {
            super(itemView);

            titleTextView = itemView.findViewById(R.id.text_title);
            contentTextView = itemView.findViewById(R.id.text_content);
            reporterTextView = itemView.findViewById(R.id.text_reporter);
            editButton = itemView.findViewById(R.id.btn_edit);
            deleteButton = itemView.findViewById(R.id.btn_delete);
        }
    }


    // 接口用于回调点击事件
    public interface OnNewsClickListener {
        void onNewsClick(News news);
    }



}
