package com.example.newroomproject.room;

import android.database.Cursor;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.OnConflictStrategy;
import androidx.room.Update;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;


@Dao
public interface NewsDao {
    @Insert
    long insertNews(News news);

    @Update
    int updateNews(News news);

    @Delete
    int deleteNews(News news);


    // 获取所有新闻
    @Query("SELECT * FROM news_table")
    List<News> getAllNews();  // 这是你需要的获取所有新闻的方法


    @Update
    int update(News news);


}
