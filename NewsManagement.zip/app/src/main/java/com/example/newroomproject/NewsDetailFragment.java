package com.example.newroomproject;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.fragment.app.Fragment;

public class NewsDetailFragment extends Fragment {

    private TextView titleTextView, contentTextView, reporterTextView;
    private Button backButton;

    public NewsDetailFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_news_detail, container, false);

        titleTextView = rootView.findViewById(R.id.news_detail_title);
        contentTextView = rootView.findViewById(R.id.news_detail_content);
        reporterTextView = rootView.findViewById(R.id.news_detail_reporter);
        backButton = rootView.findViewById(R.id.news_detail_back_button);

        // 获取数据并展示
        if (getArguments() != null) {
            String title = getArguments().getString("title");
            String content = getArguments().getString("content");
            String reporter = getArguments().getString("reporter");

            titleTextView.setText(title);
            contentTextView.setText(content);
            reporterTextView.setText(reporter);
        }


//        返回
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getParentFragmentManager().getBackStackEntryCount() > 0) {
//                  将数据展示 删除fragment
                    requireActivity().findViewById(R.id.recyclerView).setVisibility(ViewGroup.VISIBLE);
                    getParentFragmentManager().popBackStack();
                }
            }
        });

        return rootView;
    }
}

